require "import"
--蓝奏云解析原理
--1，获得网页内容
--2，拼接script内容
--3，去除JS注释
--4，获得DOM的主函数
--5，解析DOM主函数内变量分布情况(智能正则实现)
--6，根据匹配的变量反查回变量内容
--7，拼接成地址
--这个支持 变量+字符串 的单拼地址
--也支持 变量+变量 的双拼地址
--变量采用动态匹配，蓝奏云换变量名不会失效
--这个是继WebView解析后又一个智能解析
--失败率极低，速度更快
--注意，链接可能有重定向，请确定你的下载器支持重定向
--回调式解析
--使用方法：
--蓝奏云解析(蓝奏云网址,function(是否成功,数据)
--  if 是否成功 then
--    print(数据)
--   else
--    print("请求失败："..数据)
--  end
--end)
--蓝奏云网址支持自动修饰，不必一开始传入带/tp/的网址
--回调函数function(是否成功,数据)
--当第一个变量为true时，数据为解析后网址
--当第一个变量为flase时，数据为错误信息
--源码内有丰富的注释可以解答你对代码的疑惑

蓝奏云解析=function(url,callbackFUN)
  --涉及很多粗糙的正则表达式，用于截取正确内容
  --重修饰网址
  if not(url:find("/tp/")) or url:find("//lanzou") then
    local s
    if not(url:find("/tp/")) then
      s=url:match("%.com/(.+)")
     else
      s=url:match("tp/(.+)")
    end
    url="https://www.lanzous.com/tp/"..s
  end
  --发起get事件
  Http.get(url,function(code,html)
    local s,ss,sss,tmp,tmp2,tmp3,__S,__S2,k,v,n,D_doc,D_head_var,D_head,D_body_var,D_body,D_URL
    --判断响应是否成功
    if code==200 then
      --判断内容是否为空
      if #html>1 then
        --文件取消判断
        if String(html).indexOf([[来晚啦...文件取消分享了<]])>-1 and not html:find("document") then
          --执行回调函数
          callbackFUN(false,"链接已取消")
         else
          --尝试执行并捕获错误事件
          xpcall(function()
            --script标签简单获取
            tmp={}
            --去除style，垃圾玩意。妨碍我看内容
            --html=html:gsub("< ?style.->.-</ ?style.->","")
            --print(html)
            __S=html:gmatch("< ?script.->(.-)</ ?script.->")
            for v in __S do
              tmp[#tmp+1]=v
            end
            --script内容拼接
            tmp=table.concat(tmp,"\n")
            --简单去除js多行注释
            tmp=tmp:gsub("/%*.*%*/","")
            --回车补上方便切行
            tmp="\n"..tmp.."\n"
            --切行并去除空行
            tmp2={}
            __S2=tmp:gmatch("(.-)\n")
            for v in __S2 do
              --去除首尾空格缩进
              if v~="" and v:gsub(" ","")~="" then
                v=v:match("^%s*(.-)%s*$")
                tmp2[#tmp2+1]=v
              end
            end
            --去除简单的js单行注释
            for k,v in pairs(tmp2) do
              if v:find("^//") then--//开头单行注释直接移除
                table.remove(tmp2,k)
               elseif v:find("; *//") then--中途//的注释
                ss=v:match(";( *//.*)")
                sss=v:gsub(ss,"")
                tmp2[k]=sss
              end
            end
            --重新连接
            tmp3=table.concat(tmp2,"\n")
            --获得dom处主函数
            D_doc=tmp3:match("function%(document%).-%(document%)")
            --匹配结尾的下载链接头变量
            D_head_var=D_doc:match(".+= *(.-) *%+ *[\"']%??")
            if D_head_var then --如果是xxx=xx+"?xxx"单拼形式
              --匹配结尾的下载链接头
              D_head=tmp3:match(D_head_var.." *= *[\"'](.-)[\"'];?")
              --匹配结尾的下载链接尾(主体？令牌？)
              D_body=tmp3:match(D_head_var.." *%+ *[\"'](%??.-)[\"'];?")
              --拼接地址
              D_URL=D_head..D_body
             else--双变量拼接
              --获得下载链接尾变量
              D_body_var=D_doc:match(".+%+ *(.-);? *\n? *}")
              --匹配结尾的下载链接头变量
              D_head_var=tmp3:match(".+= *(.-) *%+ *"..D_body_var)
              --匹配结尾的下载链接头
              D_body=tmp3:match(D_body_var.." *= *[\"'](.-)[\"'];?")
              --匹配结尾的下载链接头
              D_head=tmp3:match(D_head_var.." *= *[\"'](.-)[\"'];?")
              --拼接地址
              D_URL=D_head..D_body
            end
            --执行回调函数
            callbackFUN(true,D_URL)
          end,function(err)
            --执行回调函数
            callbackFUN(false,"不受解析支持的网址，保报错回溯："..err)
          end)
        end
       else
        --执行回调函数
        callbackFUN(false,"网页响应数据为空")
      end
     else
      --执行回调函数
      callbackFUN(false,"网络数据请求和获取失败。错误码："..code)
    end
  end)
end

